#!/usr/bin/env zsh
# generated from catkin.builder Python module

. "/home/rosnoetic/gazebo_test_ws/devel_isolated/test/setup.zsh"
