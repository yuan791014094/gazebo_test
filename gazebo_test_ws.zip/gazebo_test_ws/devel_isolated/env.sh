#!/usr/bin/env sh
# generated from catkin.builder Python module

/home/rosnoetic/gazebo_test_ws/devel_isolated/test/env.sh "$@"
