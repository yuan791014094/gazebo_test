#!/usr/bin/env bash
# generated from catkin.builder Python module

. "/home/rosnoetic/gazebo_test_ws/devel_isolated/test/setup.bash"
